// Pravi jednu samostalnu HTML stranicu (pregled) od index.html + css + js modula.
import { readFile, writeFile } from 'node:fs/promises'
const root = new URL('../', import.meta.url)
const rd = (p) => readFile(new URL(p, root), 'utf8')
const order = ['config', 'seed', 'util', 'store', 'admin', 'app']
let js = 'window.BAKALUK_PREGLED = true;\nconst __m = {};\n'
for (const m of order) {
  let src = await rd(`js/${m}.js`)
  const names = [...src.matchAll(/^export (?:async )?(?:const|function|let) (\w+)/gm)].map((x) => x[1])
  src = src.replace(/^import \* as (\w+) from '\.\/(\w+)\.js'$/gm, "const $1 = __m['$2'];")
    .replace(/^import \{([^}]+)\} from '\.\/(\w+)\.js'$/gm, "const {$1} = __m['$2'];")
    .replace(/^export /gm, '')
  js += `__m['${m}'] = await (async () => {\n${src}\nreturn { ${names.join(', ')} };\n})();\n`
}
const html = await rd('index.html')
const body = html.match(/<!--BODY-->([\s\S]*?)<!--\/BODY-->/)[1]
const fonts = html.match(/<link rel="stylesheet" href="https:\/\/fonts[^>]+>/)[0]
const out = `<title>Bakaluk</title>\n${fonts}\n<style>\n${await rd('css/style.css')}\n</style>\n${body}\n<script type="module">\n${js}</script>\n`
const dest = process.argv[2] || 'pregled.html'
await writeFile(dest, out)
console.log('OK', dest, out.length)
