// Skida sve slike sa postojećih Bakaluk stranica i čuva ih kao .webp u images
// Pokretanje:  npm run slike
import { mkdir, writeFile } from 'node:fs/promises'
import sharp from 'sharp'

const OUT = new URL('../images/', import.meta.url)
const SITES = {
  pocetna: 'https://bakalukisporukapovrca.carrd.co/',
  porucivanje: 'https://bakalukporucivanje.carrd.co/',
  paketi: 'https://gotovipaketi.carrd.co/',
  cenovnik: 'https://bakalukizaberisadrzaj.carrd.co/',
}
// Imena koja sajt očekuje (ostale slike se čuvaju pod imenom <stranica>-<fajl>.webp)
const ALIAS = {
  'pocetna-image02': 'hero',
  'porucivanje-image01': 'basta',
  'paketi-image02': 'paket-osnovni',
  'paketi-image01': 'paket-porodicni',
  'paketi-image03': 'paket-premium',
}

await mkdir(OUT, { recursive: true })
let n = 0
for (const [site, url] of Object.entries(SITES)) {
  const html = await (await fetch(url)).text()
  const files = new Set([...html.matchAll(/assets\/images\/([\w.-]+\.(?:jpe?g|png|gif|webp))/gi)].map((m) => m[1]))
  for (const f of files) {
    if (/_original|card\./i.test(f) && files.has(f.replace('_original', ''))) continue
    try {
      const res = await fetch(new URL('assets/images/' + f, url))
      if (!res.ok) throw new Error('HTTP ' + res.status)
      const buf = Buffer.from(await res.arrayBuffer())
      const base = `${site}-${f.replace(/\.\w+$/, '')}`
      const webp = await sharp(buf).rotate().resize({ width: 1600, withoutEnlargement: true }).webp({ quality: 82 }).toBuffer()
      const names = [base, ALIAS[base]].filter(Boolean)
      for (const name of names) await writeFile(new URL(name + '.webp', OUT), webp)
      console.log('OK  ', names.join(' + '))
      n++
    } catch (e) {
      console.log('GREŠKA', site, f, e.message)
    }
  }
}
console.log(`\nSačuvano slika: ${n} → images`)
console.log('Ako neka slika nije na pravom mestu, samo je preimenuj u: hero.webp, basta.webp, paket-osnovni.webp, paket-porodicni.webp, paket-premium.webp')
