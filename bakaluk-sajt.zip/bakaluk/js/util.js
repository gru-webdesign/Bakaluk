export const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c])
export const din = (n) => Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.') + ' din'
export const num = (n) => String(n).replace('.', ',')
export const stepOf = (unit) => (unit === 'kg' ? 0.5 : 1)
export const uid = () => Math.random().toString(36).slice(2, 10)
const plural = (n, one, few, many) => (n % 10 === 1 && n % 100 !== 11 ? one : n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 12 || n % 100 > 14) ? few : many)
export function qtyLabel(q, unit) {
  if (unit === 'kg') return num(q) + ' kg'
  if (unit === 'veza') return q + ' ' + plural(q, 'veza', 'veze', 'veza')
  if (unit === 'paket') return q + ' ' + plural(q, 'paket', 'paketa', 'paketa')
  if (unit === 'kom') return q + ' kom'
  return q + ' × ' + unit
}
export const artikala = (n) => n + ' ' + plural(n, 'artikal', 'artikla', 'artikala')
export const UNITS = ['kg', 'kom', 'veza', 'kutija', 'kesa 100 g', '1 l', 'tegla 1 kg']
export const BADGES = { novo: 'Novo', jeftinije: 'Pojeftinilo', preporuka: 'Preporuka', neizvesno: 'Ako vreme dozvoli' }
export const STATUS = { nova: 'Nova', potvrdjena: 'Potvrđena', isporucena: 'Isporučena', otkazana: 'Otkazana' }
export async function copyText(text) {
  try { await navigator.clipboard.writeText(text); return true } catch { return false }
}
export function orderText(o) {
  const c = o.customer
  return [
    `BAKALUK porudžbina ${o.code}`,
    `${c.name}, tel. ${c.phone}`,
    `Adresa: ${c.street}, sprat ${c.floor}, stan ${c.apt}, ${c.zone}`,
    '',
    ...o.lines.map((l) => `• ${l.name}: ${qtyLabel(l.qty, l.unit)} = ${din(l.total)}`),
    '',
    `Vrednost: ${din(o.subtotal)}`,
    `Dostava: ${o.delivery ? din(o.delivery) : 'besplatna'}`,
    `UKUPNO: ${din(o.total)}`,
    ...(c.note ? ['', `Napomena: ${c.note}`] : []),
  ].join('\n')
}
