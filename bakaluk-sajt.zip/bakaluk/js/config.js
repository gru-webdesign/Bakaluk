// Podaci iz Firebase konzole: Project settings > Your apps > Web app.
// Dok je apiKey prazan, sajt radi u DEMO režimu (podaci se čuvaju samo u ovom pregledaču).
export const FIREBASE = {
  apiKey: '',
  authDomain: '',
  projectId: '',
  appId: '',
}

// Lozinka za admin u DEMO režimu (kad se poveže Firebase, prijava ide preko Firebase naloga)
export const DEMO_PASSWORD = 'bakaluk'
