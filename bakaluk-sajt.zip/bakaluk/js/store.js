// Sloj podataka: DEMO (localStorage) ili Firebase (Firestore + Auth), isti interfejs.
import { FIREBASE, DEMO_PASSWORD } from './config.js'
import { SEED } from './seed.js'

export const isDemo = !FIREBASE.apiKey
const KEY = 'bakaluk-db-v2'
const clone = (o) => JSON.parse(JSON.stringify(o))

// ---------- DEMO ----------
let mem = null
function local() {
  if (!mem) {
    try { mem = JSON.parse(localStorage.getItem(KEY)) } catch { mem = null }
    if (!mem || !mem.products) mem = { ...clone(SEED), orders: [] }
  }
  return mem
}
function persist() { try { localStorage.setItem(KEY, JSON.stringify(mem)) } catch { /* privatni režim */ } }
function upsert(list, item) { const i = list.findIndex((x) => x.id === item.id); if (i < 0) list.push(item); else list[i] = item }
let demoUser = null
try { demoUser = sessionStorage.getItem('bakaluk-admin') } catch { /* nema */ }

// ---------- FIREBASE ----------
const V = '11.0.2'
let fbp = null
function fb() {
  return (fbp ??= (async () => {
    const base = `https://www.gstatic.com/firebasejs/${V}/`
    const [a, f, u] = await Promise.all([import(base + 'firebase-app.js'), import(base + 'firebase-firestore.js'), import(base + 'firebase-auth.js')])
    const app = a.initializeApp(FIREBASE)
    return { f, u, db: f.getFirestore(app), auth: u.getAuth(app) }
  })())
}
async function all(name) {
  const { f, db } = await fb()
  const snap = await f.getDocs(f.collection(db, name))
  return snap.docs.map((d) => ({ ...d.data(), id: d.id }))
}
async function put(name, item) { const { f, db } = await fb(); await f.setDoc(f.doc(db, name, item.id), item) }
async function del(name, id) { const { f, db } = await fb(); await f.deleteDoc(f.doc(db, name, id)) }
const bySort = (a, b) => (a.sort ?? 0) - (b.sort ?? 0)

// ---------- KATALOG ----------
export async function loadCatalog() {
  if (isDemo) { const d = local(); return { products: d.products, packages: d.packages, settings: d.settings } }
  const { f, db } = await fb()
  const [products, packages, s] = await Promise.all([all('products'), all('packages'), f.getDoc(f.doc(db, 'settings', 'main'))])
  if (!products.length && !packages.length) return { ...clone(SEED), empty: true }
  return { products: products.sort(bySort), packages: packages.sort(bySort), settings: { ...clone(SEED.settings), ...(s.exists() ? s.data() : {}) } }
}
export async function saveProduct(p) { if (isDemo) { upsert(local().products, p); persist() } else await put('products', p) }
export async function deleteProduct(id) { if (isDemo) { mem.products = local().products.filter((x) => x.id !== id); persist() } else await del('products', id) }
export async function savePack(p) { if (isDemo) { upsert(local().packages, p); persist() } else await put('packages', p) }
export async function deletePack(id) { if (isDemo) { mem.packages = local().packages.filter((x) => x.id !== id); persist() } else await del('packages', id) }
export async function saveSettings(s) { if (isDemo) { local().settings = s; persist() } else await put('settings', { ...s, id: 'main' }) }
/** Upisuje početne podatke u praznu Firebase bazu (dugme u adminu). */
export async function seedAll() {
  const s = clone(SEED)
  await Promise.all([
    ...s.products.map((p, i) => saveProduct({ ...p, sort: i })),
    ...s.packages.map((p, i) => savePack({ ...p, sort: i })),
    saveSettings(s.settings),
  ])
}
export function resetDemo() { mem = { ...clone(SEED), orders: [] }; persist() }

// ---------- PORUDŽBINE ----------
export async function createOrder(order) {
  if (isDemo) { local().orders.unshift(order); persist(); return order.id }
  await put('orders', order); return order.id
}
export async function listOrders() {
  if (isDemo) return local().orders
  return (await all('orders')).sort((a, b) => b.createdAt - a.createdAt)
}
export async function setOrderStatus(id, status) {
  if (isDemo) { const o = local().orders.find((x) => x.id === id); if (o) o.status = status; persist(); return }
  const { f, db } = await fb(); await f.updateDoc(f.doc(db, 'orders', id), { status })
}
export async function deleteOrder(id) { if (isDemo) { mem.orders = local().orders.filter((x) => x.id !== id); persist() } else await del('orders', id) }

// ---------- PRIJAVA ----------
export async function currentUser() {
  if (isDemo) return demoUser
  const { auth } = await fb()
  await auth.authStateReady()
  return auth.currentUser ? auth.currentUser.email : null
}
export async function login(email, password) {
  if (isDemo) {
    if (password !== DEMO_PASSWORD) throw new Error('Pogrešna lozinka.')
    demoUser = email || 'demo'
    try { sessionStorage.setItem('bakaluk-admin', demoUser) } catch { /* nema */ }
    return demoUser
  }
  const { u, auth } = await fb()
  try { return (await u.signInWithEmailAndPassword(auth, email, password)).user.email }
  catch { throw new Error('Pogrešan mejl ili lozinka.') }
}
export async function logout() {
  if (isDemo) { demoUser = null; try { sessionStorage.removeItem('bakaluk-admin') } catch { /* nema */ } return }
  const { u, auth } = await fb(); await u.signOut(auth)
}
