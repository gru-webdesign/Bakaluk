// Admin: porudžbine, cenovnik, paketi, podešavanja
import * as store from './store.js'
import { esc, din, uid, qtyLabel, copyText, orderText, UNITS, BADGES, STATUS } from './util.js'

const A = { user: undefined, tab: 'porudzbine', orders: null, filter: 'nova', group: false, dirtyP: new Set(), dirtyK: new Set(), msg: '', err: '', armed: '' }
let root, ctx

export async function renderAdmin(el, context) {
  root = el; ctx = context
  if (A.user === undefined) { root.innerHTML = '<div class="wrap pad"><p>Učitavanje…</p></div>'; A.user = await store.currentUser().catch(() => null) }
  if (A.user && A.orders === null) A.orders = await store.listOrders().catch((e) => { A.err = 'Porudžbine nisu učitane: ' + e.message; return [] })
  draw()
  root.onclick = onClick; root.onchange = onChange; root.onsubmit = onSubmit
}

function draw() {
  if (!A.user) { root.innerHTML = loginView(); return }
  const tabs = { porudzbine: 'Porudžbine', cenovnik: 'Cenovnik', paketi: 'Paketi', podesavanja: 'Podešavanja' }
  const nove = (A.orders || []).filter((o) => o.status === 'nova').length
  root.innerHTML = `<div class="wrap pad admin">
    <div class="admin-top"><div><h1 class="h2">Admin</h1><p class="mute">${esc(A.user)}${store.isDemo ? ' · demo režim, podaci su samo u ovom pregledaču' : ''}</p></div>
      <button class="btn small ghost-d" data-a="logout">Odjavi se</button></div>
    ${ctx.cat.empty ? `<div class="notice">Baza je prazna, sajt trenutno prikazuje početne podatke. <button class="btn small primary" data-a="seed">Upiši početne podatke u bazu</button></div>` : ''}
    ${ctx.cat.settings.demoPrices ? `<div class="notice warn">Cene pojedinačnih artikala su primer. Unesi prave cene u kartici Cenovnik, pa isključi ovo upozorenje u Podešavanjima.</div>` : ''}
    <div class="tabs" role="tablist">${Object.entries(tabs).map(([k, v]) => `<button role="tab" aria-selected="${A.tab === k}" class="tab" data-a="tab" data-v="${k}">${v}${k === 'porudzbine' && nove ? ` <b class="count">${nove}</b>` : ''}</button>`).join('')}</div>
    ${A.msg ? `<p class="ok" role="status">${esc(A.msg)}</p>` : ''}${A.err ? `<p class="err" role="alert">${esc(A.err)}</p>` : ''}
    ${{ porudzbine: ordersView, cenovnik: productsView, paketi: packsView, podesavanja: settingsView }[A.tab]()}
  </div>`
  A.msg = ''; A.err = ''
}

function loginView() {
  return `<div class="wrap pad"><form class="card login" data-form="login" novalidate>
    <h1 class="h2">Prijava za admina</h1>
    ${store.isDemo ? `<p class="notice">Demo režim: lozinka je <b>bakaluk</b> (menja se u js/config.js). Posle povezivanja Firebase-a prijava ide preko pravog naloga.</p>` : ''}
    <label class="fld"><span>Mejl</span><input id="adm-email" name="email" type="email" autocomplete="username" value="${store.isDemo ? 'admin@bakaluk' : ''}"></label>
    <label class="fld"><span>Lozinka</span><input id="adm-pass" name="password" type="password" autocomplete="current-password"></label>
    ${A.err ? `<p class="err" role="alert">${esc(A.err)}</p>` : ''}
    <button class="btn primary">Prijavi se</button></form></div>`
}

// ---------- Porudžbine ----------
function ordersView() {
  const list = A.orders.filter((o) => A.filter === 'sve' || o.status === A.filter)
  const cnt = (s) => A.orders.filter((o) => o.status === s).length
  const chips = [['nova', 'Nove'], ['potvrdjena', 'Potvrđene'], ['isporucena', 'Isporučene'], ['otkazana', 'Otkazane'], ['sve', 'Sve']]
  let shown = list
  if (A.group) shown = [...list].sort((a, b) => a.customer.zone.localeCompare(b.customer.zone, 'sr'))
  let lastZone = null
  const sum = list.filter((o) => o.status !== 'otkazana').reduce((s, o) => s + o.total, 0)
  return `<div class="row-between"><div class="chips">${chips.map(([k, v]) => `<button class="chip" aria-pressed="${A.filter === k}" data-a="filter" data-v="${k}">${v}${k !== 'sve' ? ` (${cnt(k)})` : ''}</button>`).join('')}</div>
      <label class="check"><input type="checkbox" id="adm-group" data-a="group" ${A.group ? 'checked' : ''}> Grupiši po naselju (za rutu)</label></div>
    <p class="mute">Prikazano: ${list.length} · vrednost ${din(sum)} <button class="link" data-a="refresh">Osveži</button></p>
    ${!shown.length ? `<div class="empty">Nema porudžbina u ovoj grupi. Nove porudžbine sa sajta pojavljuju se ovde.</div>` : ''}
    <div class="orders">${shown.map((o) => {
      const head = A.group && o.customer.zone !== lastZone ? `<h3 class="zone-h">${esc((lastZone = o.customer.zone))}</h3>` : ''
      const c = o.customer
      return head + `<article class="order s-${o.status}">
        <header><b class="code">${esc(o.code)}</b><span class="mute">${new Date(o.createdAt).toLocaleString('sr-Latn-RS', { dateStyle: 'short', timeStyle: 'short' })}</span>
          <select aria-label="Status porudžbine ${esc(o.code)}" data-a="status" data-id="${esc(o.id)}">${Object.entries(STATUS).map(([k, v]) => `<option value="${k}" ${o.status === k ? 'selected' : ''}>${v}</option>`).join('')}</select></header>
        <p><b>${esc(c.name)}</b> · <span class="sel">${esc(c.phone)}</span>${c.email ? ` · ${esc(c.email)}` : ''}<br>${esc(c.street)}, sprat ${esc(c.floor)}, stan ${esc(c.apt)} · <b>${esc(c.zone)}</b></p>
        <ul class="lines">${o.lines.map((l) => `<li><span>${esc(l.name)}</span><span>${qtyLabel(l.qty, l.unit)}</span><span>${din(l.total)}</span></li>`).join('')}</ul>
        ${c.note ? `<p class="note">Napomena: ${esc(c.note)}</p>` : ''}
        <footer><span>Dostava ${o.delivery ? din(o.delivery) : 'besplatna'} · <b>Ukupno ${din(o.total)}</b></span>
          <span><button class="link" data-a="copy" data-id="${esc(o.id)}">Kopiraj</button> <button class="link danger" data-a="del-order" data-id="${esc(o.id)}">${A.armed === 'o' + o.id ? 'Sigurno obriši?' : 'Obriši'}</button></span></footer>
      </article>`
    }).join('')}</div>`
}

// ---------- Cenovnik ----------
function productsView() {
  const cats = [...new Set(ctx.cat.products.map((p) => p.category))]
  return `<p class="mute">Izmeni cenu, oznaku ili dostupnost, pa klikni „Sačuvaj izmene“. Kupci odmah vide novo stanje. Samo jedinica „kg“ ide u koracima od 0,5.</p>
    <div class="scroll-x"><table class="tbl"><thead><tr><th>Naziv</th><th>Kategorija</th><th>Jedinica</th><th>Cena (din)</th><th>Oznaka</th><th>Ima</th><th></th></tr></thead><tbody>
    ${ctx.cat.products.map((p) => `<tr>
      <td><input aria-label="Naziv" data-pid="${esc(p.id)}" data-f="name" value="${esc(p.name)}"></td>
      <td><input aria-label="Kategorija" list="cats" data-pid="${esc(p.id)}" data-f="category" value="${esc(p.category)}"></td>
      <td><input aria-label="Jedinica" list="units" data-pid="${esc(p.id)}" data-f="unit" value="${esc(p.unit)}"></td>
      <td><input aria-label="Cena" class="n" type="number" min="0" step="10" data-pid="${esc(p.id)}" data-f="price" value="${p.price}"></td>
      <td><select aria-label="Oznaka" data-pid="${esc(p.id)}" data-f="badge"><option value="">bez oznake</option>${Object.entries(BADGES).map(([k, v]) => `<option value="${k}" ${p.badge === k ? 'selected' : ''}>${v}</option>`).join('')}</select></td>
      <td><input aria-label="Dostupno" type="checkbox" data-pid="${esc(p.id)}" data-f="available" ${p.available ? 'checked' : ''}></td>
      <td><button class="link danger" data-a="del-product" data-id="${esc(p.id)}">${A.armed === 'p' + p.id ? 'Sigurno?' : 'Obriši'}</button></td></tr>`).join('')}
    </tbody></table></div><datalist id="cats">${cats.map((c) => `<option value="${esc(c)}">`).join('')}</datalist><datalist id="units">${UNITS.map((u) => `<option value="${u}">`).join('')}</datalist>
    <div class="savebar"><button class="btn ghost-d" data-a="add-product">+ Dodaj artikal</button>
      <button class="btn primary" data-a="save-products" id="save-products">Sačuvaj izmene${A.dirtyP.size ? ` (${A.dirtyP.size})` : ''}</button></div>`
}

// ---------- Paketi ----------
function packsView() {
  return `<p class="mute">Sadržaj paketa: jedna stavka u jednom redu.</p><div class="packs-admin">
    ${ctx.cat.packages.map((k) => `<div class="card">
      <label class="fld"><span>Naziv</span><input data-kid="${esc(k.id)}" data-f="name" value="${esc(k.name)}"></label>
      <label class="fld"><span>Opis</span><input data-kid="${esc(k.id)}" data-f="desc" value="${esc(k.desc)}"></label>
      <label class="fld"><span>Cena (din)</span><input class="n" type="number" min="0" step="50" data-kid="${esc(k.id)}" data-f="price" value="${k.price}"></label>
      <label class="fld"><span>Sadržaj</span><textarea rows="9" data-kid="${esc(k.id)}" data-f="items">${esc(k.items.join('\n'))}</textarea></label>
      <label class="fld"><span>Slika (ime fajla u folderu images, bez .webp)</span><input data-kid="${esc(k.id)}" data-f="image" value="${esc(k.image || '')}"></label>
      <label class="check"><input type="checkbox" data-kid="${esc(k.id)}" data-f="popular" ${k.popular ? 'checked' : ''}> Istakni kao najpopularniji</label>
      <label class="check"><input type="checkbox" data-kid="${esc(k.id)}" data-f="active" ${k.active !== false ? 'checked' : ''}> Prikaži na sajtu</label>
      <button class="link danger" data-a="del-pack" data-id="${esc(k.id)}">${A.armed === 'k' + k.id ? 'Sigurno obriši?' : 'Obriši paket'}</button>
    </div>`).join('')}</div>
    <div class="savebar"><button class="btn ghost-d" data-a="add-pack">+ Dodaj paket</button>
      <button class="btn primary" data-a="save-packs" id="save-packs">Sačuvaj izmene${A.dirtyK.size ? ` (${A.dirtyK.size})` : ''}</button></div>`
}

// ---------- Podešavanja ----------
function settingsView() {
  const s = ctx.cat.settings
  return `<form class="card settings" data-form="settings" novalidate>
    <label class="fld"><span>Nedeljna ponuda (tekst sa datumima)</span><input id="set-week" name="weekLabel" value="${esc(s.weekLabel)}"></label>
    <div class="two"><label class="fld"><span>Cena dostave (din)</span><input id="set-fee" class="n" type="number" min="0" name="deliveryFee" value="${s.deliveryFee}"></label>
    <label class="fld"><span>Besplatna dostava od (din)</span><input id="set-free" class="n" type="number" min="0" name="freeFrom" value="${s.freeFrom}"></label></div>
    <div class="two"><label class="fld"><span>Telefon (SMS, Viber, WhatsApp)</span><input id="set-phone" name="phone" value="${esc(s.phone)}"></label>
    <label class="fld"><span>Mejl</span><input id="set-email" name="email" value="${esc(s.email)}"></label></div>
    <label class="fld"><span>Naselja i dani dostave: jedno u redu, oblik „Naselje | dani“ (dani mogu ostati prazni)</span>
      <textarea id="set-zones" name="zones" rows="12">${esc(s.zones.map((z) => z.name + (z.days ? ' | ' + z.days : '')).join('\n'))}</textarea></label>
    <label class="check"><input id="set-demo" type="checkbox" name="demoPrices" ${s.demoPrices ? 'checked' : ''}> Prikaži upozorenje da su cene primer</label>
    <div class="savebar"><button class="btn primary">Sačuvaj podešavanja</button>
    ${store.isDemo ? `<button type="button" class="link danger" data-a="reset">${A.armed === 'reset' ? 'Sigurno? Briše sve demo podatke' : 'Vrati demo na početak'}</button>` : ''}</div>
  </form>`
}

// ---------- Događaji ----------
function arm(key) { if (A.armed === key) { A.armed = ''; return true } A.armed = key; draw(); return false }

async function onClick(e) {
  const b = e.target.closest('[data-a]'); if (!b || b.tagName === 'SELECT' || b.type === 'checkbox') return
  const a = b.dataset.a, id = b.dataset.id
  try {
    if (a === 'tab') { A.tab = b.dataset.v; A.armed = '' }
    else if (a === 'filter') A.filter = b.dataset.v
    else if (a === 'logout') { await store.logout(); A.user = null; A.orders = null }
    else if (a === 'refresh') { A.orders = await store.listOrders(); A.msg = 'Lista je osvežena.' }
    else if (a === 'seed') { await store.seedAll(); await ctx.reload(); A.msg = 'Početni podaci su upisani u bazu.' }
    else if (a === 'copy') { const ok = await copyText(orderText(A.orders.find((o) => o.id === id))); A.msg = ok ? 'Porudžbina je kopirana.' : 'Kopiranje nije uspelo u ovom pregledaču.' }
    else if (a === 'del-order') { if (!arm('o' + id)) return; await store.deleteOrder(id); A.orders = A.orders.filter((o) => o.id !== id) }
    else if (a === 'add-product') { const p = { id: uid(), name: 'Novi artikal', category: 'Povrće', unit: 'kg', price: 0, badge: '', available: false }; ctx.cat.products.push(p); A.dirtyP.add(p.id) }
    else if (a === 'del-product') { if (!arm('p' + id)) return; await store.deleteProduct(id); ctx.cat.products = ctx.cat.products.filter((p) => p.id !== id); A.dirtyP.delete(id) }
    else if (a === 'save-products') {
      await Promise.all(ctx.cat.products.map((p, i) => { const ch = p.sort !== i || A.dirtyP.has(p.id); p.sort = i; return ch ? store.saveProduct(p) : null }))
      A.dirtyP.clear(); A.msg = 'Cenovnik je sačuvan.'
    }
    else if (a === 'add-pack') { const k = { id: uid(), name: 'Novi paket', desc: '', price: 0, items: [], image: '', popular: false, active: false }; ctx.cat.packages.push(k); A.dirtyK.add(k.id) }
    else if (a === 'del-pack') { if (!arm('k' + id)) return; await store.deletePack(id); ctx.cat.packages = ctx.cat.packages.filter((k) => k.id !== id); A.dirtyK.delete(id) }
    else if (a === 'save-packs') {
      await Promise.all(ctx.cat.packages.map((k, i) => { const ch = k.sort !== i || A.dirtyK.has(k.id); k.sort = i; return ch ? store.savePack(k) : null }))
      A.dirtyK.clear(); A.msg = 'Paketi su sačuvani.'
    }
    else if (a === 'reset') { if (!arm('reset')) return; store.resetDemo(); await ctx.reload(); A.orders = []; A.msg = 'Demo je vraćen na početak.' }
    else return
  } catch (err) { A.err = 'Nije uspelo: ' + err.message }
  draw()
}

async function onChange(e) {
  const t = e.target
  if (t.dataset.a === 'group') { A.group = t.checked; draw(); return }
  if (t.dataset.a === 'status') {
    const o = A.orders.find((x) => x.id === t.dataset.id)
    try { await store.setOrderStatus(o.id, t.value); o.status = t.value } catch (err) { A.err = 'Status nije sačuvan: ' + err.message }
    draw(); return
  }
  const f = t.dataset.f; if (!f) return
  const val = t.type === 'checkbox' ? t.checked : t.type === 'number' ? Math.max(0, Number(t.value) || 0) : f === 'items' ? t.value.split('\n').map((x) => x.trim()).filter(Boolean) : t.value.trim()
  if (t.dataset.pid) {
    const p = ctx.cat.products.find((x) => x.id === t.dataset.pid); p[f] = val; A.dirtyP.add(p.id)
    root.querySelector('#save-products').textContent = `Sačuvaj izmene (${A.dirtyP.size})`
  } else if (t.dataset.kid) {
    const k = ctx.cat.packages.find((x) => x.id === t.dataset.kid); k[f] = val; A.dirtyK.add(k.id)
    root.querySelector('#save-packs').textContent = `Sačuvaj izmene (${A.dirtyK.size})`
  }
}

async function onSubmit(e) {
  const form = e.target.closest('[data-form]'); if (!form) return
  e.preventDefault()
  const d = Object.fromEntries(new FormData(form))
  try {
    if (form.dataset.form === 'login') { A.user = await store.login(d.email.trim(), d.password); A.orders = await store.listOrders().catch(() => []) }
    else {
      const s = ctx.cat.settings
      Object.assign(s, {
        weekLabel: d.weekLabel.trim(), phone: d.phone.trim(), email: d.email.trim(),
        deliveryFee: Math.max(0, Number(d.deliveryFee) || 0), freeFrom: Math.max(0, Number(d.freeFrom) || 0),
        demoPrices: !!d.demoPrices,
        zones: d.zones.split('\n').map((l) => { const [name, days = ''] = l.split('|').map((x) => x.trim()); return { name, days } }).filter((z) => z.name),
      })
      await store.saveSettings(s); A.msg = 'Podešavanja su sačuvana.'
    }
  } catch (err) { A.err = err.message }
  draw()
}
