// Javni deo: početna, ponuda, paketi, korpa, potvrda + ruter
import { loadCatalog, createOrder, isDemo } from './store.js'
import { renderAdmin } from './admin.js'
import { esc, din, qtyLabel, stepOf, uid, artikala, copyText, orderText, BADGES } from './util.js'

const S = { cat: null, cart: {}, form: {}, errors: {}, last: null, zone: '', filter: 'Sve', sending: false, copied: '' }
try { S.cart = JSON.parse(localStorage.getItem('bakaluk-korpa')) || {} } catch { S.cart = {} }
try { S.form = JSON.parse(localStorage.getItem('bakaluk-kupac')) || {} } catch { S.form = {} }
const saveCart = () => { try { localStorage.setItem('bakaluk-korpa', JSON.stringify(S.cart)) } catch { /* privatni režim */ } }

const $ = (id) => document.getElementById(id)
const route = () => location.hash.replace(/^#\/?/, '') || 'pocetna'
const ph = (name, cls = '') => `<div class="ph ${cls}">${name && !window.BAKALUK_PREGLED ? `<img src="images/${esc(name)}.webp" alt="" loading="lazy">` : ''}</div>`
// ako slika ne postoji, ostaje zamenski blok
document.addEventListener('error', (e) => { if (e.target.tagName === 'IMG') e.target.remove() }, true)

// ---------- Korpa ----------
function item(key) {
  const [t, id] = key.split(':')
  if (t === 'p') { const p = S.cat.products.find((x) => x.id === id); return p && p.available ? { key, name: p.name, unit: p.unit, price: p.price } : null }
  const k = S.cat.packages.find((x) => x.id === id)
  return k && k.active !== false ? { key, name: k.name, unit: 'paket', price: k.price } : null
}
function totals() {
  const lines = Object.entries(S.cart).map(([key, qty]) => { const it = item(key); return it && qty > 0 ? { ...it, qty, total: Math.round(it.price * qty) } : null }).filter(Boolean)
  const subtotal = lines.reduce((s, l) => s + l.total, 0), st = S.cat.settings
  const delivery = !lines.length || subtotal >= st.freeFrom ? 0 : st.deliveryFee
  return { lines, subtotal, delivery, total: subtotal + delivery, left: Math.max(0, st.freeFrom - subtotal) }
}
function setQty(key, qty) {
  qty = Math.min(99, Math.max(0, Math.round(qty * 2) / 2))
  if (qty) S.cart[key] = qty; else delete S.cart[key]
  saveCart()
}
function stepper(key, unit, label) {
  const q = S.cart[key] || 0
  if (!q) return `<button class="btn add" data-act="inc" data-key="${esc(key)}" aria-label="Dodaj ${esc(label)}">Dodaj</button>`
  return `<div class="qty"><button data-act="dec" data-key="${esc(key)}" aria-label="Manje: ${esc(label)}">−</button><output>${['kg', 'veza', 'kom', 'paket'].includes(unit) ? qtyLabel(q, unit) : q}</output><button data-act="inc" data-key="${esc(key)}" aria-label="Više: ${esc(label)}">+</button></div>`
}

// ---------- Zajednički delovi ----------
function header() {
  const r = route(), n = totals().lines.length
  const link = (h, t) => `<a href="#${h}" ${r === h ? 'aria-current="page"' : ''}>${t}</a>`
  $('head').innerHTML = `<div class="wrap head-in">
    <a class="logo" href="#pocetna" aria-label="Bakaluk, početna"><svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true"><path fill="currentColor" d="M12 22c0-7 1-11 8-18-9 1-15 5-15 11 0 2 1 4 3 5 1-4 3-7 6-9-3 3-4 7-4 11z"/></svg>Bakaluk</a>
    <nav aria-label="Glavna navigacija">${link('ponuda', 'Ponuda')}${link('paketi', 'Paketi')}
      <a class="cart-link" href="#korpa" ${r === 'korpa' ? 'aria-current="page"' : ''}>Korpa${n ? `<b class="count">${n}</b>` : ''}</a></nav></div>`
}
function bar() {
  const t = totals(), r = route(), el = $('bar')
  const show = t.lines.length && ['pocetna', 'ponuda', 'paketi'].includes(r)
  el.hidden = !show
  document.body.classList.toggle('has-bar', !!show)
  if (!show) return
  const st = S.cat.settings, pct = Math.min(100, (t.subtotal / st.freeFrom) * 100)
  el.innerHTML = `<div class="wrap bar-in"><div class="bar-info"><b>${artikala(t.lines.length)} · ${din(t.subtotal)}</b>
      <span>${t.left ? `Još ${din(t.left)} do besplatne dostave` : 'Dostava je besplatna'}</span>
      <div class="meter" role="presentation"><i style="width:${pct}%"></i></div></div>
    <a class="btn primary" href="#korpa">Pregledaj i poruči</a></div>`
}
const badge = (b) => (b && BADGES[b] ? `<span class="badge b-${b}">${BADGES[b]}</span>` : '')
function packCard(k) {
  const key = 'k:' + k.id
  return `<article class="pack ${k.popular ? 'pop' : ''}">${ph(k.image, 'ph-pack')}
    <div class="pack-body">${k.popular ? '<span class="badge b-preporuka">Najpopularniji</span>' : ''}
      <h3>${esc(k.name)}</h3><p class="mute">${esc(k.desc)}</p>
      <ul class="pack-items">${k.items.map((i) => `<li>${esc(i)}</li>`).join('')}</ul>
      <div class="pack-foot"><span class="price">${din(k.price)}</span>${stepper(key, 'paket', k.name)}</div></div></article>`
}
const activePacks = () => S.cat.packages.filter((k) => k.active !== false)

// ---------- Stranice ----------
function home() {
  const st = S.cat.settings, top = S.cat.products.filter((p) => p.available).slice(0, 6)
  const z = st.zones.find((x) => x.name === S.zone)
  return `<section class="hero"><div class="wrap hero-grid">
      <div class="hero-text"><p class="eyebrow">Dostava u Beogradu · ponuda za ${esc(st.weekLabel)}</p>
        <h1>Iz bašte pravo <em>na tvoja vrata.</em></h1>
        <p class="lead">Domaće povrće, voće i jaja, gajeni uz preparate koji se koriste i u organskoj proizvodnji. Sastavi svoju korpu ili uzmi gotov paket.</p>
        <div class="cta"><a class="btn primary big" href="#ponuda">Sastavi svoju korpu</a><a class="btn ghost big" href="#paketi">Uzmi gotov paket</a></div>
        <p class="hero-note">Besplatna dostava za porudžbine od ${din(st.freeFrom)}. Za manje porudžbine dostava je ${din(st.deliveryFee)}.</p></div>
      <div class="hero-art">${ph('hero', 'ph-hero')}
        <div class="tabla" aria-label="Deo ovonedeljnog cenovnika"><p class="tabla-h">Ove nedelje</p>
          ${top.map((p) => `<div class="tabla-row"><span>${esc(p.name)}</span><i></i><b>${din(p.price).replace(' din', '')}</b><small>/${esc(p.unit)}</small></div>`).join('')}
          <a href="#ponuda">Ceo cenovnik</a></div></div>
    </div></section>

    <section class="wrap sec"><h2 class="h2">Kako se poručuje</h2>
      <ol class="steps"><li><b>Izaberi</b><span>Dodaj povrće po svom izboru ili uzmi jedan od gotovih paketa.</span></li>
        <li><b>Pošalji porudžbinu</b><span>Upiši ime, adresu i telefon. Nema registracije.</span></li>
        <li><b>Potvrda i dostava</b><span>Javljamo se SMS-om ili Viberom da potvrdimo dostupnost i termin.</span></li></ol></section>

    <section class="wrap sec"><div class="row-between"><h2 class="h2">Gotovi paketi</h2><a class="more" href="#paketi">Svi paketi</a></div>
      <div class="packs">${activePacks().map(packCard).join('')}</div></section>

    <section class="band"><div class="wrap band-grid">
      <div><h2 class="h2">Da li dolazimo u tvoj kraj?</h2>
        <p>Dostavljamo od Ledina do Višnjičke Banje i od Zemuna do Vidikovca, u krajevima u koje već redovno idemo.</p>
        <label class="fld"><span>Izaberi naselje</span><select id="zone-check" data-act="zone"><option value="">Naselje…</option>
          ${st.zones.map((x) => `<option ${x.name === S.zone ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}<option value="-" ${S.zone === '-' ? 'selected' : ''}>Nema mog naselja</option></select></label>
        <p class="zone-out" role="status">${z ? (z.days ? `U naselje ${esc(z.name)} dolazimo: <b>${esc(z.days)}</b>.` : `Dostavljamo u naselje ${esc(z.name)}. Termin potvrđujemo porukom posle porudžbine.`) : S.zone === '-' ? `Javi nam se na ${esc(st.phone)}, proverićemo da li možemo da dođemo.` : ''}</p></div>
      <ul class="perks"><li>Sveže, ukusno i kvalitetno povrće, voće i jaja</li><li>Sam biraš sadržaj paketa ili uzimaš gotov</li>
        <li>Gajeno uz preparate koji se koriste i u organskoj proizvodnji</li><li>Cene i ponuda se osvežavaju svakog ponedeljka</li></ul>
    </div></section>

    <section class="wrap sec contact">${ph('basta', 'ph-wide')}
      <div><h2 class="h2">Radije poručuješ porukom?</h2>
        <p>Porudžbinu možeš poslati i preko SMS-a, Vibera ili WhatsApp-a, kao i mejlom.</p>
        <p class="big-num sel">${esc(st.phone)}</p><p class="sel">${esc(st.email)}</p>
        <div class="cta"><button class="btn ghost-d" data-act="copy" data-text="${esc(st.phone)}">${S.copied === st.phone ? 'Kopirano' : 'Kopiraj broj'}</button>
          <a class="btn ghost-d" href="${esc(st.facebook)}" target="_blank" rel="noopener">Facebook</a><a class="btn ghost-d" href="${esc(st.instagram)}" target="_blank" rel="noopener">Instagram</a></div></div></section>`
}

const norm = (s) => s.toLowerCase().replace(/đ/g, 'dj').normalize('NFD').replace(/[\u0300-\u036f]/g, '')
function plist() {
  const q = norm(S.q || '').trim()
  const list = S.cat.products.filter((p) => (q ? norm(p.name).includes(q) : S.filter === 'Sve' || S.filter === p.category))
  const cats = [...new Set(list.map((p) => p.category))]
  if (!list.length) return `<div class="empty">Nema artikla „${esc(S.q)}“ u ovonedeljnoj ponudi.</div>`
  return cats.map((c) => `<h2 class="cat-h">${esc(c)}</h2><ul class="plist">${list.filter((p) => p.category === c).map((p) => `
      <li class="${p.available ? '' : 'off'}"><div class="pname"><b>${esc(p.name)}</b>${badge(p.badge)}</div><i class="dots"></i>
        <div class="pprice"><b>${din(p.price).replace(' din', '')}</b> din/${esc(p.unit)}</div>
        <div class="pact">${p.available ? stepper('p:' + p.id, p.unit, p.name) : '<span class="mute">Trenutno nema</span>'}</div></li>`).join('')}</ul>`).join('')
}
function ponuda() {
  const st = S.cat.settings, cats = [...new Set(S.cat.products.map((p) => p.category))]
  const used = [...new Set(S.cat.products.map((p) => p.badge).filter(Boolean))]
  return `<section class="wrap pad"><p class="eyebrow dark">Nedeljna ponuda · ${esc(st.weekLabel)}</p><h1 class="h1">Sastavi svoju korpu</h1>
    <p class="lead-d">Artikli na kilogram idu u koracima od 0,5 kg. Besplatna dostava od ${din(st.freeFrom)}.</p>
    <label class="fld search"><span>Pretraži ponudu (${S.cat.products.length} artikala)</span><input id="q" type="search" data-act="q" value="${esc(S.q || '')}" placeholder="npr. paradajz, sok, brašno" autocomplete="off"></label>
    <div class="chips">${['Sve', ...cats].map((c) => `<button class="chip" aria-pressed="${!S.q && S.filter === c}" data-act="filter" data-v="${esc(c)}">${esc(c)}</button>`).join('')}</div>
    ${used.length ? `<div class="legend">${used.map(badge).join('')}</div>` : ''}
    <div id="plist">${plist()}</div></section>`
}

function paketi() {
  return `<section class="wrap pad"><p class="eyebrow dark">Brza kupovina</p><h1 class="h1">Gotovi paketi</h1>
    <p class="lead-d">Sveže, sezonsko i spremno za trpezu. Paketu možeš da dodaš i pojedinačne artikle iz <a href="#ponuda">ponude</a>.</p>
    <div class="packs">${activePacks().map(packCard).join('')}</div></section>`
}

const FIELDS = [['name', 'Ime i prezime', 'text', 'name'], ['phone', 'Telefon', 'tel', 'tel'], ['street', 'Ulica i broj', 'text', 'street-address'], ['floor', 'Sprat', 'text', 'off'], ['apt', 'Broj stana', 'text', 'off']]
function korpa() {
  const t = totals(), st = S.cat.settings, f = S.form, e = S.errors
  if (!t.lines.length) return `<section class="wrap pad"><h1 class="h1">Korpa je prazna</h1><p class="lead-d">Dodaj povrće iz ponude ili izaberi gotov paket.</p>
    <div class="cta"><a class="btn primary" href="#ponuda">Pogledaj ponudu</a><a class="btn ghost-d" href="#paketi">Gotovi paketi</a></div></section>`
  const fld = ([k, label, type, ac]) => `<label class="fld ${e[k] ? 'bad' : ''}"><span>${label} *</span><input id="f-${k}" data-f="${k}" type="${type}" autocomplete="${ac}" value="${esc(f[k] || '')}" ${k === 'floor' || k === 'apt' ? 'placeholder="za kuću upiši /"' : ''} ${e[k] ? `aria-invalid="true" aria-describedby="e-${k}"` : ''}>${e[k] ? `<em id="e-${k}">${e[k]}</em>` : ''}</label>`
  return `<section class="wrap pad checkout"><div><h1 class="h1">Tvoja porudžbina</h1>
      <ul class="cart">${t.lines.map((l) => `<li><div><b>${esc(l.name)}</b><span class="mute">${din(l.price)}/${esc(l.unit)}</span></div>${stepper(l.key, l.unit, l.name)}<b class="lt">${din(l.total)}</b></li>`).join('')}</ul>
      <a class="more" href="#ponuda">Dodaj još artikala</a>
      <dl class="sum"><div><dt>Vrednost</dt><dd>${din(t.subtotal)}</dd></div>
        <div><dt>Dostava</dt><dd>${t.delivery ? din(t.delivery) : 'besplatna'}</dd></div>
        ${t.left ? `<p class="hint">Dodaj još ${din(t.left)} i dostava je besplatna.</p>` : ''}
        <div class="tot"><dt>Ukupno</dt><dd>${din(t.total)}</dd></div></dl></div>
    <form class="card order-form" data-form="order" novalidate><h2 class="h3">Podaci za dostavu</h2>
      ${fld(FIELDS[0])}${fld(FIELDS[1])}${fld(FIELDS[2])}<div class="two">${fld(FIELDS[3])}${fld(FIELDS[4])}</div>
      <label class="fld ${e.zone ? 'bad' : ''}"><span>Naselje *</span><input id="f-zone" data-f="zone" list="zones" autocomplete="off" value="${esc(f.zone || '')}" placeholder="npr. ${esc(st.zones[0]?.name || 'Zemun')}" ${e.zone ? 'aria-invalid="true" aria-describedby="e-zone"' : ''}>${e.zone ? `<em id="e-zone">${e.zone}</em>` : ''}</label>
      <datalist id="zones">${st.zones.map((z) => `<option value="${esc(z.name)}">`).join('')}</datalist>
      <label class="fld"><span>Mejl (nije obavezno)</span><input id="f-email" data-f="email" type="email" autocomplete="email" value="${esc(f.email || '')}"></label>
      <label class="fld"><span>Napomena (nije obavezno)</span><textarea id="f-note" data-f="note" rows="3">${esc(f.note || '')}</textarea></label>
      ${e._ ? `<p class="err" role="alert">${esc(e._)}</p>` : ''}
      <button class="btn primary big full" ${S.sending ? 'disabled' : ''}>${S.sending ? 'Šaljem…' : `Pošalji porudžbinu · ${din(t.total)}`}</button>
      <p class="mute small">Posle slanja javljamo se SMS-om ili Viberom da potvrdimo dostupnost i termin dostave.</p></form></section>`
}

function hvala() {
  const o = S.last, st = S.cat.settings
  if (!o) return korpa()
  const text = orderText(o)
  return `<section class="wrap pad thanks"><p class="eyebrow dark">Porudžbina ${esc(o.code)}</p><h1 class="h1">Porudžbina je primljena.</h1>
    <p class="lead-d">Hvala, ${esc(o.customer.name.split(' ')[0])}. Javićemo se SMS-om ili Viberom na ${esc(o.customer.phone)} sa potvrdom i terminom dostave.</p>
    <div class="card"><h2 class="h3">Kopija porudžbine</h2><pre class="sel" id="order-text">${esc(text)}</pre>
      <div class="cta"><button class="btn primary" data-act="copy" data-text="${esc(text)}">${S.copied === text ? 'Kopirano' : 'Kopiraj poruku'}</button>
        <a class="btn ghost-d" href="viber://chat?number=%2B381${esc(st.phone.replace(/\D/g, '').replace(/^0/, ''))}">Otvori Viber</a></div>
      <p class="mute small">Ako želiš da budeš siguran da smo je videli, nalepi poruku u Viber na broj <b class="sel">${esc(st.phone)}</b> ili u mejl na <b class="sel">${esc(st.email)}</b>.</p></div>
    <a class="more" href="#pocetna">Nazad na početnu</a></section>`
}

// ---------- Crtanje i događaji ----------
function render(focus) {
  const r = route()
  header(); bar()
  $('foot').hidden = false
  if (r === 'admin') { $('bar').hidden = true; renderAdmin($('app'), { cat: S.cat, reload }); return }
  $('app').onclick = $('app').onchange = $('app').onsubmit = null
  $('app').innerHTML = ({ pocetna: home, ponuda, paketi, korpa, hvala }[r] || home)()
  if (focus) document.querySelector(focus)?.focus({ preventScroll: true })
}
async function reload() { S.cat = await loadCatalog(); return S.cat }

document.addEventListener('click', async (e) => {
  const b = e.target.closest('[data-act]'); if (!b) return
  const { act, key } = b.dataset
  if (act === 'inc' || act === 'dec') {
    const unit = key.startsWith('p:') ? item(key)?.unit : 'paket'
    setQty(key, (S.cart[key] || 0) + (act === 'inc' ? 1 : -1) * stepOf(unit))
    const sel = `[data-key="${CSS.escape(key)}"]`
    render(document.querySelector(`[data-act="${act}"]${sel}`) && S.cart[key] ? `[data-act="${act}"]${sel}` : sel)
  } else if (act === 'filter') { S.filter = b.dataset.v; S.q = ''; render(`[data-act="filter"][aria-pressed="true"]`) }
  else if (act === 'copy') {
    const ok = await copyText(b.dataset.text)
    if (ok) { S.copied = b.dataset.text; render(); setTimeout(() => { S.copied = ''; if (route() !== 'admin') render() }, 2500) }
    else { const pre = $('order-text'); if (pre) getSelection().selectAllChildren(pre) }
  }
})
document.addEventListener('change', (e) => { if (e.target.dataset.act === 'zone') { S.zone = e.target.value; render('#zone-check') } })
document.addEventListener('input', (e) => {
  if (e.target.dataset.act === 'q') { S.q = e.target.value; $('plist').innerHTML = plist(); document.querySelectorAll('.chip').forEach((c) => c.setAttribute('aria-pressed', String(!S.q && c.dataset.v === S.filter))); return }
  const f = e.target.dataset.f
  if (!f || route() !== 'korpa') return
  S.form[f] = e.target.value
  try { localStorage.setItem('bakaluk-kupac', JSON.stringify({ ...S.form, note: '' })) } catch { /* privatni režim */ }
})
document.addEventListener('submit', async (e) => {
  const form = e.target.closest('[data-form="order"]'); if (!form) return
  e.preventDefault()
  const f = S.form, err = {}
  for (const [k, label] of FIELDS) if (!(f[k] || '').trim()) err[k] = `Upiši: ${label.toLowerCase()}.`
  if (!err.phone && (f.phone.match(/\d/g) || []).length < 8) err.phone = 'Telefon treba da ima bar 8 cifara.'
  if (!(f.zone || '').trim()) err.zone = 'Upiši naselje da znamo kada dolazimo.'
  S.errors = err
  const first = Object.keys(err)[0]
  if (first) { render('#f-' + first); document.querySelector('#f-' + first)?.scrollIntoView({ block: 'center' }); return }
  const t = totals(), tr = (v) => (v || '').trim().slice(0, 300)
  const order = {
    id: uid() + uid(), code: 'BK-' + uid().slice(0, 5).toUpperCase(), createdAt: Date.now(), status: 'nova',
    customer: { name: tr(f.name), phone: tr(f.phone), street: tr(f.street), floor: tr(f.floor), apt: tr(f.apt), zone: tr(f.zone), email: tr(f.email), note: tr(f.note) },
    lines: t.lines, subtotal: t.subtotal, delivery: t.delivery, total: t.total,
  }
  S.sending = true; render()
  try {
    await createOrder(order)
    S.last = order; S.cart = {}; saveCart(); S.form.note = ''; S.sending = false
    location.hash = 'hvala'
  } catch (ex) {
    S.sending = false
    S.errors = { _: `Porudžbina nije poslata (${ex.message}). Pokušaj ponovo ili je pošalji porukom na ${S.cat.settings.phone}.` }
    render()
  }
})
window.addEventListener('hashchange', () => { S.errors = {}; render(); window.scrollTo(0, 0) })

// ---------- Start ----------
reload().then(() => {
  $('foot').innerHTML = `<div class="wrap foot-in"><span>Bakaluk · isporuka domaćeg povrća, voća i jaja u Beogradu</span>
    <span class="sel">${esc(S.cat.settings.phone)} · ${esc(S.cat.settings.email)}</span><a href="#admin">Admin</a>${isDemo ? '<span class="demo-tag">demo režim</span>' : ''}</div>`
  render()
}).catch((ex) => { $('app').innerHTML = `<div class="wrap pad"><h1 class="h2">Ponuda trenutno nije dostupna</h1><p>Osveži stranicu za koji minut. (${esc(ex.message)})</p></div>` })
