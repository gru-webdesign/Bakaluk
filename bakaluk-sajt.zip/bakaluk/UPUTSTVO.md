# Bakaluk: uputstvo

Sajt nema build korak. Folder se otvara i postavlja takav kakav jeste.

## 1. Pokretanje na računaru
U folderu projekta: `npx serve .` pa otvori adresu koju ispiše (dupli klik na index.html ne radi, pregledač traži lokalni server).

## 2. Slike
```
npm install
npm run slike
```
Skripta skida sve slike sa četiri stare Carrd stranice i čuva ih kao `.webp` u `images/`. Ako neka završi pod pogrešnim imenom, preimenuj je prema `images/PROCITAJ.txt`.

## 3. Demo režim
Dok je `js/config.js` prazan, podaci se čuvaju samo u pregledaču. Admin je na `#admin`, lozinka `bakaluk`. Ovo služi samo za probu: porudžbine iz demo režima ne stižu vlasniku.

## 4. Povezivanje Firebase-a (prava baza)
1. console.firebase.google.com > Add project.
2. Build > Firestore Database > Create database (production mode, region europe-west).
3. Build > Authentication > Sign-in method > uključi Email/Password. U kartici Users dodaj jedan nalog za admina.
4. Firestore > Rules: nalepi sadržaj fajla `firestore.rules`, zameni `ADMIN_EMAIL_OVDE` mejlom tog naloga, Publish.
5. Project settings > Your apps > Web (</>) > registruj aplikaciju i prepiši `apiKey`, `authDomain`, `projectId`, `appId` u `js/config.js`.
6. Otvori sajt, idi na `#admin`, prijavi se i klikni „Upiši početne podatke u bazu“.
7. U kartici Cenovnik unesi prave cene, u Podešavanjima upiši dane dostave po naseljima.

## 5. Postavljanje
- Netlify: Sites > Add new site > Deploy manually, prevuci ceo folder.
- Cloudflare Pages: Create > Pages > Upload assets, prevuci ceo folder.
Posle toga u Firebase > Authentication > Settings > Authorized domains dodaj adresu sajta.

## Šta je gde
- `index.html`, `css/style.css`: izgled
- `js/seed.js`: početni artikli, paketi, naselja
- `js/store.js`: rad sa bazom (demo ili Firebase)
- `js/app.js`: javne stranice, korpa, forma
- `js/admin.js`: admin
